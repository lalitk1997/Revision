package io.project.JUnit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JUnitApplicationTests {

	@Test
	void contextLoads() {
	}

}
