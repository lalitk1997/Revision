package com.security.masai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MasaiApplication.class, args);
	}

}
